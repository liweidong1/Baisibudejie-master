//
//  TGPicVC.h
//  baisibudejie
//
//  Created by targetcloud on 2017/3/8.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import "TGTopicVC.h"

@interface TGPicVC : TGTopicVC

@end
