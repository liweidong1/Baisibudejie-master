//
//  TGVoiceVC.m
//  baisibudejie
//
//  Created by targetcloud on 2017/3/8.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import "TGVoiceVC.h"

@interface TGVoiceVC ()

@end

@implementation TGVoiceVC

- (TGTopicType)type{
    return TGTopicTypeVoice;
}

@end
