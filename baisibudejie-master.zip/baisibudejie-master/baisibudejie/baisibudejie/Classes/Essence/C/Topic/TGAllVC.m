//
//  TGAllVC.m
//  baisibudejie
//
//  Created by targetcloud on 2017/3/8.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import "TGAllVC.h"

@interface TGAllVC ()

@end

@implementation TGAllVC

- (TGTopicType)type{
    return TGTopicTypeAll;
}

-(BOOL) showAD{
    return YES;
}

@end
