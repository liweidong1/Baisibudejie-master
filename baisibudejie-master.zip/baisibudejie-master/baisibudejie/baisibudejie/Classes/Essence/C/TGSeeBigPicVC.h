//
//  TGSeeBigPicVC.h
//  baisibudejie
//
//  Created by targetcloud on 2017/3/14.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TGTopicM;

@interface TGSeeBigPicVC : UIViewController
@property (nonatomic, strong) TGTopicM *topic;
@end
