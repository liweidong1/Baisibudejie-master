//
//  TGNewestAlbumVC.h
//  baisibudejie
//
//  Created by targetcloud on 2017/5/31.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import "TGTopicNewVC.h"

@interface TGNewestAlbumVC : TGTopicNewVC

@end
