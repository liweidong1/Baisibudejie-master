//
//  TGEssenceNewVC.h
//  baisibudejie
//
//  Created by targetcloud on 2017/5/29.
//  Copyright © 2017年 targetcloud. All rights reserved.
//  Blog http://blog.csdn.net/callzjy
//  Mail targetcloud@163.com
//  Github https://github.com/targetcloud

#import <UIKit/UIKit.h>

@interface TGEssenceNewVC : UIViewController

@end
