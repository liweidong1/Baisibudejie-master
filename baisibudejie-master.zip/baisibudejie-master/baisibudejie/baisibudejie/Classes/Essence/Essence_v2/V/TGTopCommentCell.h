//
//  TGTopCommentCell.h
//  baisibudejie
//
//  Created by targetcloud on 2017/6/4.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TGCommentNewM;

@interface TGTopCommentCell : UITableViewCell
@property (strong , nonatomic)TGCommentNewM *commentM;
@end
