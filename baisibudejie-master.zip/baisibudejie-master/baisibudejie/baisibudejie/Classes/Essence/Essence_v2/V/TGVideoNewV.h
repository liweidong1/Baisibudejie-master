//
//  TGVideoNewV.h
//  baisibudejie
//
//  Created by targetcloud on 2017/5/30.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TGTopicNewM;

@interface TGVideoNewV : UIView
@property (nonatomic, strong) TGTopicNewM *topic;
@end
