//
//  TGCommentCell.h
//  baisibudejie
//
//  Created by targetcloud on 2017/5/23.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TGCommentM;

@interface TGCommentCell : UITableViewCell
@property (strong , nonatomic)TGCommentM *comment;
@end
