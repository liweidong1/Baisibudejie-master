//
//  TGCommentVC.h
//  baisibudejie
//
//  Created by targetcloud on 2017/5/23.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TGTopicM;

@interface TGCommentVC : UIViewController
@property (nonatomic, strong) TGTopicM *topic;
@end
