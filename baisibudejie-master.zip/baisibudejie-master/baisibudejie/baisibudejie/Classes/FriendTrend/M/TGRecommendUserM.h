//
//  TGRecommendUserM.h
//  baisibudejie
//
//  Created by targetcloud on 2017/5/16.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TGRecommendUserM : NSObject
@property (nonatomic, copy) NSString *header;
@property (nonatomic, assign) NSInteger fans_count;
@property (nonatomic, copy) NSString *screen_name;
@end
