//
//  TGRecommendUserCell.h
//  baisibudejie
//
//  Created by targetcloud on 2017/5/16.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TGRecommendUserM;

@interface TGRecommendUserCell : UITableViewCell
@property (nonatomic, strong) TGRecommendUserM *user;
@end
