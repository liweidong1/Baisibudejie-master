//
//  TGSubTagM.h
//  baisibudejie
//
//  Created by targetcloud on 2017/3/6.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TGSubTagM : NSObject
@property (nonatomic, copy) NSString *theme_name;
@property (nonatomic, copy) NSString *image_list;
@property (nonatomic, copy) NSString *sub_number;
@end
