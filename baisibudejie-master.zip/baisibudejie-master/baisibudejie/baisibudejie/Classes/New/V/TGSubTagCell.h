//
//  TGSubTagCell.h
//  baisibudejie
//
//  Created by targetcloud on 2017/3/6.
//  Copyright © 2017年 targetcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TGSubTagM;

@interface TGSubTagCell : UITableViewCell
@property (nonatomic, strong) TGSubTagM *item;
@end
